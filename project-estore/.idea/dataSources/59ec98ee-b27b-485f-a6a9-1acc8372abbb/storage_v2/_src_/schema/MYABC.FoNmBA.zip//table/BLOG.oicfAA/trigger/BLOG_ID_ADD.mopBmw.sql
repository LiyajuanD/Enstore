create trigger BLOG_ID_ADD
    before insert
    on BLOG
    for each row
    when (NEW."ID" IS NULL)
BEGIN
  SELECT BLOG_ID.NEXTVAL
  INTO :NEW."ID"
  FROM DUAL;
END;
/

